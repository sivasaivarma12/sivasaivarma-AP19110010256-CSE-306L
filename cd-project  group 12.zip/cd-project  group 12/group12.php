<?php
	$s = 0;
	/* multi-line
	commenr */
	$i = 0;
	$b = 20 * 4 + 15;
	// single line comment
	while($i < 100){
		$s = $s + $i;
		$i = $i + 1;
	}
?>
